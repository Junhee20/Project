function runValidate(form){
    if(validateName(form) && Country(form)){
        return false; 
    }
} 
function validateName(form){
    var fName = form.elements["fullname"];
    if(fName.validity.valueMissing){
        fName.setCustomValidity("Write your full name here");
        return false;
    }    
    else{
        fName.setCustomValidity(" ");
        return true;
    }
}
function Country(form){
    var from = form.elements["country"];
    if(from.validity.valueMissing){from.setCustomValidity("Write your country here");
        return false;        
    }
    else{
        from.setCustomValidity("");
        return true;
    }
} 

const name =document.getElementById('fullName')
const country = document.getElementById('country')
const favorite = document.getElementById('favorite')
const age = document.getElementById('age')
const mood = document.getElementById('moods')
const form = document.getElementById('myform')