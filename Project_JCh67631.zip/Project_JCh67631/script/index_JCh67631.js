
//rudolph
window.addEventListener("DOMContentLoaded",function(){
    setInterval(runRudolph,Rudolph, 100);
});


function runRudolph(){
    let rudolph = document.getElementById("rudolph");
    rudolph.style.visibility = "visible";
}
function Rudolph(){
    let rudolph = document.getElementById("rudolph2");
    rudolph.style.visibility = "visible";
}